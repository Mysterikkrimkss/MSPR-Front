#import <Flutter/Flutter.h>

@interface QrscanPlugin : NSObject<FlutterPlugin>
@end
