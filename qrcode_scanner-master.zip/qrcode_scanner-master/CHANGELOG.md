## 0.0.1 - (2019/04/7)
## 0.0.2 - (2019/04/7)
## 0.0.3 - (2019/04/7)
## 0.1.0 - (2019/04/8)
## 0.1.1 - (2019/04/8)
## 0.1.2 - (2019/04/8)
## 0.1.3 - (2019/04/8)
## 0.1.4 - (2019/04/11)
## 0.1.5 - (2019/04/29)
## 0.1.6 - (2019/05/18)
## 0.1.7 - (2019/08/01)  light up  back view
## 0.1.8 - (2019/08/01)  update style
## 0.1.9 - (2019/08/01)  update style
## 0.2.0 - (2019/08/01)  update style
## 0.2.1 - (2019/08/03)  Adjust the layout
## 0.2.2 - (2019/08/05)  Apply for camera privileges
## 0.2.3 - (2019/08/05)  Scanning BR-CODE and QR-CODE in albums
## 0.2.4 - (2019/08/05)
## 0.2.5 - (2019/08/07)  Display the switch button of the flashlight according to the light intensity
## 0.2.6 - (2019/08/07)
## 0.2.7 - (2019/08/07)
## 0.2.8 - (2019/08/07)  Generate QR-CODE
## 0.2.9 - (2019/08/09)  Update demo style
## 0.2.10 - (2019/08/09)  Update Readme
## 0.2.11 - (2019/08/14)  Update Readme
## 0.2.12 - (2019/08/19)  Migrate to AndroidX
## 0.2.13 - (2019/08/20)  Migrate to AndroidX
## 0.2.14 - (2019/08/24)  Repair the problem of scanned pictures
## 0.2.15 - (2019/08/30)  Select photo on the scan page to scanning.
## 0.2.16 - (2019/09/06)  Scanning the image of the specified path.
## 0.2.17 - (2019/09/06)  Parse to code string with uint8list.
## 0.2.18 - (2019/10/28)  On back pressed return null.
## 0.2.19 - (2020/11/25)  Support QR code generation for iOS
## 0.2.20 - (2020/12/08)  Remove unnecessarily asking for permissions at startup
## 0.2.21 - (2020/12/09)  Show toast when there's exception on light
## 0.2.22 - (2021/01/27)  Always throws the error when the analyze fails